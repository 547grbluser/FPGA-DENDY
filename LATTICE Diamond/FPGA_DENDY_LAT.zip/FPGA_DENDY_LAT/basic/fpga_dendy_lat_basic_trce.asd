[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 72.301 MHz (42.954 MHz);
Fmax_1 = 26.207 MHz (21.477 MHz);
Fmax_2 = - (-);
Failed = 0 (Total 3);
Clock_ports = 2;
Clock_nets = 3;
; Hold Analysis
Fmax_0 = 0.304 ns (0.000 ns);
Fmax_1 = 0.260 ns (0.000 ns);
Fmax_2 = - (-);
Failed = 0 (Total 3);
Clock_ports = 2;
Clock_nets = 3;
